export interface IPrivateMessage {
    Username: string;
    Message: string;
}